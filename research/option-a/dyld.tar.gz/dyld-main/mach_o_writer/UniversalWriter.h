/*
 * Copyright (c) 2017-2021 Apple Inc. All rights reserved.
 *
 * @APPLE_LICENSE_HEADER_START@
 *
 * This file contains Original Code and/or Modifications of Original Code
 * as defined in and that are subject to the Apple Public Source License
 * Version 2.0 (the 'License'). You may not use this file except in
 * compliance with the License. Please obtain a copy of the License at
 * http://www.opensource.apple.com/apsl/ and read it before using this
 * file.
 *
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 * Please see the License for the specific language governing rights and
 * limitations under the License.
 *
 * @APPLE_LICENSE_HEADER_END@
 */


#ifndef mach_o_writer_Universal_h
#define mach_o_writer_Universal_h

#include <stdint.h>
#include <mach-o/fat.h>

#include <span>

// mach_o
#include "Architecture.h"
#include "GradedArchitectures.h"
#include "UnsafeHeader.h"
#include "Universal.h"

namespace mach_o {

using namespace mach_o;

/*!
 * @class UniversalWriter
 *
 * @abstract
 *      Abstraction for fat files
 */
struct VIS_HIDDEN UniversalWriter : public Universal
{
    // for building
    static const UniversalWriter*   make(std::span<const UnsafeHeader*>, bool forceFat64=false, bool arm64offEnd=false);

    static const UniversalWriter*   make(std::span<const Slice>, bool forceFat64=false, bool arm64offEnd=false);
    void                            save(char savedPath[PATH_MAX]) const;
    bool                            saveToPath(const char* path, uint32_t permissions=0644) const;
    uint64_t                        size() const;
    std::span<const uint8_t>        content() const;
    void                            free() const;   // only called on object allocated by make()
};


} // namespace mach_o

#endif /* mach_o_writer_Universal_h */
