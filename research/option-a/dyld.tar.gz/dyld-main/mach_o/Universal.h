/*
 * Copyright (c) 2017-2021 Apple Inc. All rights reserved.
 *
 * @APPLE_LICENSE_HEADER_START@
 *
 * This file contains Original Code and/or Modifications of Original Code
 * as defined in and that are subject to the Apple Public Source License
 * Version 2.0 (the 'License'). You may not use this file except in
 * compliance with the License. Please obtain a copy of the License at
 * http://www.opensource.apple.com/apsl/ and read it before using this
 * file.
 *
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 * Please see the License for the specific language governing rights and
 * limitations under the License.
 *
 * @APPLE_LICENSE_HEADER_END@
 */


#ifndef mach_o_Universal_h
#define mach_o_Universal_h

#include <stdint.h>
#include <mach-o/fat.h>

#include <span>

#include "Architecture.h"
#include "GradedArchitectures.h"
#include "UnsafeHeader.h"

namespace mach_o {


/*!
 * @class Universal
 *
 * @abstract
 *      Abstraction for fat files
 */
struct VIS_HIDDEN Universal
{
    struct Slice
    {
        Architecture             arch;
        std::span<const uint8_t> buffer;
        uint64_t                 fileOffset = 0;
        uint8_t                  alignment  = 0; // power of 2
    };

    // for examining universal files
    static const Universal* isUniversal(std::span<const uint8_t> fileContent);
    Error                   valid(uint64_t fileSize) const;
    void                    forEachSlice(void (^callback)(Slice slice, bool& stop)) const;
    bool                    bestSlice(const GradedArchitectures& ga, bool osBinary, Slice& slice) const;
    uint32_t                sliceCount() const;
    const char*             archNames(char strBuf[256]) const;
    const char*             archAndPlatformNames(char strBuf[512]) const;
    static uint8_t          defaultAlignment(std::span<const uint8_t> fileContent);

protected:
    Error                   validSlice(Architecture sliceArch, uint64_t sliceOffset, uint64_t sliceLen) const;
    void                    forEachSlice(void (^callback)(Architecture arch, uint64_t sliceOffset, uint64_t sliceSize, uint8_t sliceAlignment, bool& stop)) const;

                            Universal();
    void                    addMachO(const UnsafeHeader*);
    enum { kMaxSliceCount = 16 };

protected:
    alignas(4096) fat_header   fh;
};


} // namespace mach_o

#endif /* mach_o_Universal_h */
